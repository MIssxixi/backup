//
//  AppDelegate.h
//  Demo
//
//  Created by Mac_ZL on 16/7/28.
//  Copyright © 2016年 Mac_ZL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

