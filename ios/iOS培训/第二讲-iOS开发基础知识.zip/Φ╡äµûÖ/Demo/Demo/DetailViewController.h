//
//  DetailViewController.h
//  Demo
//
//  Created by Mac_ZL on 16/8/2.
//  Copyright © 2016年 Mac_ZL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (nonatomic ,strong) NSString *text;

@end
