//
//  TEUserModel.m
//  ZYJProject
//
//  Created by yongjie_zou on 16/10/14.
//  Copyright © 2016年 yongjie_zou. All rights reserved.
//

#import "TEUserModel.h"

@implementation TEUserModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey{
    return @{
             
             };
}

@end
