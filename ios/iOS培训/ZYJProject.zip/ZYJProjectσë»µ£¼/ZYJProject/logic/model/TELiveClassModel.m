//
//  TELiveClassModel.m
//  ZYJProject
//
//  Created by yongjie_zou on 16/10/14.
//  Copyright © 2016年 yongjie_zou. All rights reserved.
//

#import "TELiveClassModel.h"

@implementation TELiveClassModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey{
    return @{
             @"name" : @"name",
             @"timestamp" : @"timestamp"
             };
}

@end
