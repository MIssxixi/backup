//
//  TETip.h
//  ZYJProject
//
//  Created by yongjie_zou on 16/10/14.
//  Copyright © 2016年 yongjie_zou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TETip : NSObject

+ (void)show:(NSString *)message;

@end
